# PrimeCloud — Real Working Hosting Website

A GitHub-ready, PHP + JavaScript + TypeScript + JSON project inspired by the supplied PrimeCloud UI reference.

## Included
- Modern dark blue/cyan cloud hosting UI
- Responsive Home, Minecraft, VPS, Domains, Services pages
- Register / Login / Logout
- Session-based authentication with PHP
- Password hashing with PHP `password_hash`
- JSON persistent storage — no MySQL/native database required
- User dashboard
- Notifications
- Redeem-code system
- Admin dashboard
- Admin user/code/order management
- Plan catalog
- Pterodactyl API integration foundation for real server controls
- Real API routes for health, catalog, auth, user data, admin data and Pterodactyl actions
- TypeScript source files for frontend logic
- No secrets committed

## Requirements
- PHP 8.1+
- A PHP server (Apache, Nginx, PHP built-in server, or hosting panel)
- Optional: Node.js 18+ if you want to compile/edit TypeScript

## Run locally
```bash
php -S 0.0.0.0:8080 -t public
```

Then open:
`http://127.0.0.1:8080`

The API is served through `/api/*.php`.

## Pterodactyl
Set these environment variables on the server:
- `PTERO_URL`
- `PTERO_API_KEY`
- `PTERO_CLIENT_KEY` (optional for client-side server controls)
- `PTERO_APPLICATION_KEY` (for application API actions)

Never put API keys into frontend JavaScript.

## Important
The website is fully functional as a website/application with JSON storage. Real payments, domain registration, and Pterodactyl provisioning require the credentials/API access of the provider. The project includes safe integration points rather than fake payment or fake provisioning success.
