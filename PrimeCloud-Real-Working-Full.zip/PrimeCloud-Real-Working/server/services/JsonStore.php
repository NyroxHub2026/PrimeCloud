<?php
declare(strict_types=1);

final class JsonStore {
    private string $file;
    public function __construct(string $file) {
        $this->file = $file;
        $dir = dirname($file);
        if (!is_dir($dir)) mkdir($dir, 0775, true);
        if (!file_exists($file)) file_put_contents($file, json_encode([
            'users'=>[], 'sessions'=>[], 'codes'=>[], 'orders'=>[], 'notifications'=>[]
        ], JSON_PRETTY_PRINT));
    }
    public function read(): array {
        $fp = fopen($this->file,'c+');
        flock($fp, LOCK_SH);
        $raw = stream_get_contents($fp);
        flock($fp, LOCK_UN); fclose($fp);
        $data = json_decode($raw ?: '{}', true);
        return is_array($data) ? $data : [];
    }
    public function update(callable $fn): array {
        $fp = fopen($this->file,'c+');
        flock($fp, LOCK_EX);
        $raw = stream_get_contents($fp);
        $data = json_decode($raw ?: '{}', true);
        if (!is_array($data)) $data = [];
        $data = $fn($data);
        ftruncate($fp,0); rewind($fp);
        fwrite($fp,json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
        fflush($fp); flock($fp,LOCK_UN); fclose($fp);
        return $data;
    }
}
