<?php
declare(strict_types=1);

final class AuthService {
    public static function token(): string { return bin2hex(random_bytes(32)); }
    public static function userPublic(array $u): array {
        unset($u['password_hash']);
        return $u;
    }
    public static function requireUser(JsonStore $store): array {
        $token = $_COOKIE['primecloud_session'] ?? '';
        if (!$token) self::fail(401,'Login required');
        $d=$store->read();
        foreach($d['sessions']??[] as $s){
            if(hash_equals($s['token'],$token) && ($s['expires']??0)>time()){
                foreach($d['users']??[] as $u) if($u['id']===$s['user_id']) return $u;
            }
        }
        self::fail(401,'Session expired');
    }
    public static function setSession(JsonStore $store,string $uid): void {
        $token=self::token();
        $store->update(function($d)use($token,$uid){
            $d['sessions']=array_values(array_filter($d['sessions']??[],fn($s)=>($s['expires']??0)>time()));
            $d['sessions'][]=['token'=>$token,'user_id'=>$uid,'expires'=>time()+60*60*24*7];
            return $d;
        });
        setcookie('primecloud_session',$token,['expires'=>time()+604800,'path'=>'/','httponly'=>true,'samesite'=>'Lax','secure'=>(!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')]);
    }
    public static function logout(JsonStore $store): void {
        $token=$_COOKIE['primecloud_session']??'';
        $store->update(function($d)use($token){$d['sessions']=array_values(array_filter($d['sessions']??[],fn($s)=>$s['token']!==$token));return $d;});
        setcookie('primecloud_session','',['expires'=>1,'path'=>'/','httponly'=>true,'samesite'=>'Lax']);
    }
    public static function fail(int $code,string $msg): never {
        http_response_code($code); header('Content-Type: application/json'); echo json_encode(['ok'=>false,'error'=>$msg]); exit;
    }
}
