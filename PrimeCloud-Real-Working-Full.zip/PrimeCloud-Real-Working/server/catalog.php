<?php
return [
'minecraft'=>[
 ['id'=>'mc2','name'=>'Starter','ram'=>'2 GB','price'=>40,'currency'=>'₹','tag'=>'Budget'],
 ['id'=>'mc4','name'=>'Basic','ram'=>'4 GB','price'=>80,'currency'=>'₹','tag'=>'Popular'],
 ['id'=>'mc6','name'=>'Pro','ram'=>'6 GB','price'=>120,'currency'=>'₹','tag'=>''],
 ['id'=>'mc8','name'=>'Advanced','ram'=>'8 GB','price'=>180,'currency'=>'₹','tag'=>''],
 ['id'=>'mc12','name'=>'Power','ram'=>'12 GB','price'=>220,'currency'=>'₹','tag'=>''],
 ['id'=>'mc16','name'=>'Ultra','ram'=>'16 GB','price'=>280,'currency'=>'₹','tag'=>''],
 ['id'=>'mc24','name'=>'Titan','ram'=>'24 GB','price'=>320,'currency'=>'₹','tag'=>''],
 ['id'=>'mc32','name'=>'Extreme','ram'=>'32 GB','price'=>444,'currency'=>'₹','tag'=>'']
],
'vps'=>[
 ['id'=>'vps4','name'=>'Starter','ram'=>'4 GB','cpu'=>'2 vCPU','disk'=>'20 GB SSD','price'=>299,'currency'=>'₹'],
 ['id'=>'vps8','name'=>'Advanced','ram'=>'8 GB','cpu'=>'4 vCPU','disk'=>'40 GB SSD','price'=>519,'currency'=>'₹'],
 ['id'=>'vps16','name'=>'Pro','ram'=>'16 GB','cpu'=>'8 vCPU','disk'=>'70 GB SSD','price'=>649,'currency'=>'₹'],
 ['id'=>'vps32','name'=>'Ultra','ram'=>'32 GB','cpu'=>'8 vCPU','disk'=>'90 GB SSD','price'=>1049,'currency'=>'₹']
],
'domains'=>[
 ['tld'=>'.in','price'=>1000],['tld'=>'.com','price'=>1000],['tld'=>'.xyz','price'=>1900],
 ['tld'=>'.online','price'=>900],['tld'=>'.site','price'=>1900],['tld'=>'.store','price'=>3000]
],
'services'=>[
 ['name'=>'Pterodactyl Installation','desc'=>'Install and configure a production panel.'],
 ['name'=>'Websites & Dashboards','desc'=>'Modern responsive websites and admin panels.'],
 ['name'=>'Discord Bots','desc'=>'Deploy and manage Discord bot projects.'],
 ['name'=>'VPS / Server Setup','desc'=>'Configure Linux servers and hosting infrastructure.']
]
];
