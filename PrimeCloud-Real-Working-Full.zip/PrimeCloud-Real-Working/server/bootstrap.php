<?php
declare(strict_types=1);
require_once __DIR__.'/services/JsonStore.php';
require_once __DIR__.'/services/AuthService.php';
header('Content-Type: application/json; charset=utf-8');
$store=new JsonStore(__DIR__.'/../data/primecloud.json');

function body(): array {
    $raw=file_get_contents('php://input');
    $d=json_decode($raw?:'{}',true);
    return is_array($d)?$d:[];
}
function ok(array $data=[]): never { echo json_encode(['ok'=>true]+$data,JSON_UNESCAPED_SLASHES); exit; }
