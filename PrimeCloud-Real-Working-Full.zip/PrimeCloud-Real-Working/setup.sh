#!/usr/bin/env bash
set -e
mkdir -p data
echo "PrimeCloud files ready."
echo "Run: php -S 0.0.0.0:8080 -t public"
