import {api} from "./main";
export async function login(email:string,password:string){return api<{user:unknown}>(`/api/auth.php?action=login`,{method:"POST",body:JSON.stringify({email,password})});}
export async function register(username:string,email:string,password:string){return api<{user:unknown}>(`/api/auth.php?action=register`,{method:"POST",body:JSON.stringify({username,email,password})});}
export async function logout(){return api<{}>(`/api/auth.php?action=logout`,{method:"POST"});}
