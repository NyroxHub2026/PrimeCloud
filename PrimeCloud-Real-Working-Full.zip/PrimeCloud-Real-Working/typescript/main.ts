type ApiResult<T>={ok:boolean}&T;
export async function api<T>(url:string, options:RequestInit={}):Promise<ApiResult<T>>{
 const response=await fetch(url,{credentials:"same-origin",headers:{"Content-Type":"application/json"},...options});
 const data=await response.json();
 if(!response.ok) throw new Error(data.error||"Request failed");
 return data;
}
export const money=(n:number)=>`₹${n.toFixed(2)}`;
