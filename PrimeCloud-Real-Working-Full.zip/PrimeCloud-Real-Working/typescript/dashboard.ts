import {api} from "./main";
export async function dashboard(){return api<{user:unknown;orders:unknown[];notifications:unknown[]}>(`/api/user.php?action=dashboard`);}
export async function redeem(code:string){return api<{message:string}>(`/api/user.php?action=redeem`,{method:"POST",body:JSON.stringify({code})});}
