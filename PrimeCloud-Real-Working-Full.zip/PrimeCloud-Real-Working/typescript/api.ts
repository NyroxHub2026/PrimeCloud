export interface User{id:string;username:string;email:string;role:string;balance:number}
export interface Plan{id:string;name:string;price:number;currency:string;ram?:string;cpu?:string;disk?:string}
export const endpoints={catalog:"/api/catalog.php",auth:"/api/auth.php",user:"/api/user.php",admin:"/api/admin.php",pterodactyl:"/api/pterodactyl.php"};
