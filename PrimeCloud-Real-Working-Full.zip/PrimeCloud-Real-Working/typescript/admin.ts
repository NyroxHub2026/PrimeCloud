import {api} from "./main";
export async function adminStats(){return api<{users:number;orders:number;codes:number;revenue:number}>(`/api/admin.php?action=stats`);}
export async function createCode(code:string,amount:number){return api<{code:unknown}>(`/api/admin.php?action=codes`,{method:"POST",body:JSON.stringify({code,amount})});}
