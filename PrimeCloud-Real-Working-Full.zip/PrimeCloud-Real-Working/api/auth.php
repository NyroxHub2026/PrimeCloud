<?php
require_once __DIR__.'/../server/bootstrap.php';
$action=$_GET['action']??'me';
if($action==='me'){
  try{$u=AuthService::requireUser($store); ok(['user'=>AuthService::userPublic($u)]);}catch(Throwable $e){http_response_code(401);echo json_encode(['ok'=>false,'user'=>null]);exit;}
}
if($action==='logout'){AuthService::logout($store);ok();}
$d=body();
if($action==='register'){
 $email=strtolower(trim((string)($d['email']??'')));$username=trim((string)($d['username']??''));$pw=(string)($d['password']??'');
 if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($username)<3||strlen($pw)<8) AuthService::fail(422,'Please enter valid account details.');
 $data=$store->read(); foreach($data['users'] as $u) if(strtolower($u['email'])===$email) AuthService::fail(409,'Email already registered.');
 $u=['id'=>'usr_'.bin2hex(random_bytes(5)),'username'=>$username,'email'=>$email,'role'=>'user','balance'=>0,'created_at'=>date(DATE_ATOM),'password_hash'=>password_hash($pw,PASSWORD_DEFAULT)];
 $store->update(function($x)use($u){$x['users'][]=$u;$x['notifications'][]=['id'=>bin2hex(random_bytes(4)),'user_id'=>$u['id'],'text'=>'Welcome to PrimeCloud!','created_at'=>date(DATE_ATOM),'read'=>false];return $x;});
 AuthService::setSession($store,$u['id']); ok(['user'=>AuthService::userPublic($u)]);
}
if($action==='login'){
 $email=strtolower(trim((string)($d['email']??'')));$pw=(string)($d['password']??'');$data=$store->read();
 foreach($data['users'] as $u) if(strtolower($u['email'])===$email && password_verify($pw,$u['password_hash'])){AuthService::setSession($store,$u['id']);ok(['user'=>AuthService::userPublic($u)]);}
 AuthService::fail(401,'Invalid email or password.');
}
AuthService::fail(404,'Unknown auth action.');
