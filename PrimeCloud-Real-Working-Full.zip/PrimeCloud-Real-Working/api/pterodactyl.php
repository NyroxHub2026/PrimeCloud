<?php
require_once __DIR__.'/../server/bootstrap.php';
$u=AuthService::requireUser($store);
$action=$_GET['action']??'status';
$base=rtrim(getenv('PTERO_URL')?:'','/');
$key=getenv('PTERO_APPLICATION_KEY')?:getenv('PTERO_API_KEY')?:'';
if(!$base||!$key) AuthService::fail(503,'Pterodactyl API is not configured on the server.');
function ptero(string $method,string $path,array $payload=[]): array {
 global $base,$key;
 $ch=curl_init($base.$path); curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$key,'Accept: Application/vnd.pterodactyl.v1+json','Content-Type: application/json']]);
 if($payload)curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($payload));
 $raw=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
 $data=json_decode($raw?:'{}',true);if($code>=400)AuthService::fail($code,'Pterodactyl request failed.');return $data?:[];
}
if($action==='servers')ok(['servers'=>ptero('GET','/api/application/servers?per_page=100')['data']??[]]);
if($action==='server'){
 $id=(int)($_GET['id']??0);if(!$id)AuthService::fail(422,'Server id required.');ok(['server'=>ptero('GET','/api/application/servers/'.$id)]);
}
if(in_array($action,['start','stop','restart'],true)){
 $id=(int)($_GET['id']??0);$client=getenv('PTERO_CLIENT_KEY')?:$key;
 $ch=curl_init($base.'/api/client/servers/'.rawurlencode((string)$id).'/power');curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode(['signal'=>$action==='start'?'start':($action==='stop'?'stop':'restart')]),CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$client,'Accept: Application/vnd.pterodactyl.v1+json','Content-Type: application/json']]);curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);if($code>=300)AuthService::fail($code,'Power action failed.');ok(['message'=>'Power action sent']);
}
AuthService::fail(404,'Unknown Pterodactyl action.');
