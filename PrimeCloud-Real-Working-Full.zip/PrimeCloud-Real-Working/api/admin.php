<?php
require_once __DIR__.'/../server/bootstrap.php';
$u=AuthService::requireUser($store); if(($u['role']??'')!=='admin') AuthService::fail(403,'Admin access required.');
$action=$_GET['action']??'stats';$d=$store->read();
if($action==='stats')ok(['users'=>count($d['users']??[]),'orders'=>count($d['orders']??[]),'codes'=>count($d['codes']??[]),'revenue'=>array_sum(array_map(fn($o)=>(float)($o['amount']??0),$d['orders']??[]))]);
if($action==='users')ok(['users'=>array_map(fn($x)=>AuthService::userPublic($x),$d['users']??[])]);
if($action==='codes'){
 if($_SERVER['REQUEST_METHOD']==='POST'){
   $b=body();$amount=(float)($b['amount']??0);if($amount<=0)AuthService::fail(422,'Amount must be positive.');
   $c=['id'=>'code_'.bin2hex(random_bytes(4)),'code'=>strtoupper($b['code']??bin2hex(random_bytes(4))),'amount'=>$amount,'used'=>false,'created_at'=>date(DATE_ATOM)];
   $store->update(function($x)use($c){$x['codes'][]=$c;return $x;});ok(['code'=>$c]);
 }
 ok(['codes'=>$d['codes']??[]]);
}
if($action==='broadcast'){
 $msg=trim((string)(body()['message']??''));if($msg==='')AuthService::fail(422,'Message required.');
 $store->update(function($x)use($msg){foreach($x['users'] as $usr)$x['notifications'][]=['id'=>bin2hex(random_bytes(4)),'user_id'=>$usr['id'],'text'=>$msg,'created_at'=>date(DATE_ATOM),'read'=>false];return $x;});ok(['message'=>'Broadcast sent']);
}
AuthService::fail(404,'Unknown admin action.');
