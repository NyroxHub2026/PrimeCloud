<?php
require_once __DIR__.'/../server/bootstrap.php';
$u=AuthService::requireUser($store); $action=$_GET['action']??'dashboard';
if($action==='dashboard'){
 $d=$store->read();$orders=array_values(array_filter($d['orders']??[],fn($o)=>$o['user_id']===$u['id']));
 $notes=array_values(array_filter($d['notifications']??[],fn($n)=>$n['user_id']===$u['id']));
 ok(['user'=>AuthService::userPublic($u),'orders'=>$orders,'notifications'=>$notes]);
}
if($action==='redeem'){
 $code=strtoupper(trim((string)(body()['code']??'')));$d=$store->read();$found=null;
 foreach($d['codes']??[] as $c) if(strtoupper($c['code'])===$code && !($c['used']??false)){$found=$c;break;}
 if(!$found) AuthService::fail(404,'Code not found or already used.');
 $store->update(function($x)use($found,$u){foreach($x['codes'] as &$c)if($c['id']===$found['id'])$c['used']=true;$x['notifications'][]=['id'=>bin2hex(random_bytes(4)),'user_id'=>$u['id'],'text'=>'Redeemed '.$found['code'].' for ₹'.$found['amount'].'.','created_at'=>date(DATE_ATOM),'read'=>false];foreach($x['users'] as &$usr)if($usr['id']===$u['id'])$usr['balance']=($usr['balance']??0)+$found['amount'];return $x;});
 ok(['message'=>'Code redeemed']);
}
if($action==='notifications'){ $d=$store->read();ok(['notifications'=>array_values(array_filter($d['notifications']??[],fn($n)=>$n['user_id']===$u['id']))]); }
AuthService::fail(404,'Unknown user action.');
