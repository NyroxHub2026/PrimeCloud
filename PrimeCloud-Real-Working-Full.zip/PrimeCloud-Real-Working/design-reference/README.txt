This is the supplied UI reference image. It is not used as the website background; the UI is recreated with HTML/CSS so controls remain real and interactive.
